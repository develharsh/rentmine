module.exports = {
  env: {
    "BASE_URL": "https://RentMine.vercel.app/",
    "MONGODB_URL": "mongodb+srv://hvs:thakur@cluster0.h3zc7.mongodb.net/rentmine?retryWrites=true&w=majority",
    "JWT_SECRET": "!)@(#*$&%^",
    "TOKEN_EXPIRE":"7d",
    "CLOUD_UPDATE_PRESET": "duskanddawn",
    "CLOUD_NAME": "duskanddawn",
    "CLOUD_API": "https://api.cloudinary.com/v1_1/duskanddawn/image/upload"
  },
  images: {
    domains: ['res.cloudinary.com'],
  },
}